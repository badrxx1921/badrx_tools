import 'package:flutter/material.dart';
import 'pages/download_page.dart';
import 'pages/moyen_calc_page.dart';
import 'pages/ai_chat_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'badrx tools',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Arial',
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Welcome in badrx tools!!')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            buildButton(context, 'Download video by link 💻', const DownloadPage()),
            const SizedBox(height: 15),
            buildButton(context, 'حساب معدل الأطوار الثلاثة', const MoyenCalcPage()),
            const SizedBox(height: 15),
            buildButton(context, 'محادثة مع الذكاء الاصطناعي 🤖', const AiChatPage()),
          ],
        ),
      ),
    );
  }

  Widget buildButton(BuildContext context, String title, Widget page) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        backgroundColor: Colors.indigo,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      onPressed: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => page),
      ),
      child: Text(title, style: const TextStyle(fontSize: 18)),
    );
  }
}