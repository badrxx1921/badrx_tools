import 'package:flutter/material.dart';

class MoyenCalcPage extends StatelessWidget {
  const MoyenCalcPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حساب المعدل')),
      body: const Center(child: Text('واجهة حساب المعدل')),
    );
  }
}