import 'package:flutter/material.dart';

class DownloadPage extends StatelessWidget {
  const DownloadPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Download Video')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            ElevatedButton(onPressed: () {}, child: const Text('YouTube')),
            ElevatedButton(onPressed: () {}, child: const Text('TikTok')),
            ElevatedButton(onPressed: () {}, child: const Text('Instagram')),
            ElevatedButton(onPressed: () {}, child: const Text('Facebook')),
          ],
        ),
      ),
    );
  }
}