import 'package:flutter/material.dart';

class AiChatPage extends StatelessWidget {
  const AiChatPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الذكاء الاصطناعي')),
      body: const Center(child: Text('واجهة الذكاء الاصطناعي')),
    );
  }
}